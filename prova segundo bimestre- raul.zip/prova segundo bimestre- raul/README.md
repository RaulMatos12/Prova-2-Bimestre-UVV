# Prova2B

Projeto para Prova de Programação Avançada para a Web

O Objetivo era criar uma API usando TypeScript e o Prisma ORM que implementasse os modelos: Users, Post e Comment assim criando um mecanismo de atenticação de sennha de forma que somente usuários autenticados possam realizar operações sobre Posts e Comments
